import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Dimensions, FlatList, StatusBar } from 'react-native';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  useAnimatedScrollHandler,
  withTiming,
  withDelay,
  withSpring,
  interpolate,
  interpolateColor,
  Extrapolate,
  Easing,
} from 'react-native-reanimated';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Button from '../../components/Button';
import AnimatedBackground from '../../components/AnimatedBackground';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows, Motion } from '../../constants/theme';
import { useResponsiveDimensions } from '../../hooks/useResponsiveDimensions';

const { width, height } = Dimensions.get('window');

const slides = [
  {
    id: '1',
    icon: 'paw',
    title: 'Tudo para o seu pet',
    subtitle: 'Em um só lugar',
    description: 'Encontre os melhores produtos e serviços pet da sua região. Qualidade, confiança e amor ao seu alcance.',
    gradient: Colors.gradientTwilight,
    bgGradient: [...Colors.gradientAurora],
    iconColor: Colors.twilight,
    particles: ['🐕', '🐈', '🦴', '🎾'],
  },
  {
    id: '2',
    icon: 'location-sharp',
    title: 'Perto de você',
    subtitle: 'Entrega rápida',
    description: 'Descubra pet shops, clínicas veterinárias e serviços próximos. Tudo com entrega rápida e segura.',
    gradient: Colors.gradientSky,
    bgGradient: [...Colors.gradientBlue, Colors.secondary],
    iconColor: Colors.secondary,
    particles: ['📍', '🚀', '⚡', '💫'],
  },
  {
    id: '3',
    icon: 'calendar',
    title: 'Agende serviços',
    subtitle: 'Simples e rápido',
    description: 'Banho, tosa, consultas veterinárias e muito mais. Agende com facilidade direto pelo app.',
    gradient: Colors.gradientSunset,
    bgGradient: [Colors.accent, Colors.warning, '#FF6B6B'],
    iconColor: Colors.accent,
    particles: ['✨', '💖', '🌟', '⭐'],
  },
];

function Particle({ emoji, index, scrollX, slideIndex }) {
  const randomX = Math.random() * width - width / 2;
  const randomY = Math.random() * height * 0.4 - height * 0.2;
  const randomDuration = 3000 + Math.random() * 2000;
  
  const animatedStyle = useAnimatedStyle(() => {
    const inputRange = [
      (slideIndex - 1) * width,
      slideIndex * width,
      (slideIndex + 1) * width,
    ];
    
    const opacity = interpolate(
      scrollX.value,
      inputRange,
      [0, 1, 0],
      Extrapolate.CLAMP
    );
    
    const translateY = interpolate(
      scrollX.value,
      inputRange,
      [50, 0, -50],
      Extrapolate.CLAMP
    );
    
    const scale = interpolate(
      scrollX.value,
      inputRange,
      [0.5, 1, 0.5],
      Extrapolate.CLAMP
    );

    return {
      opacity: opacity * 0.6,
      transform: [
        { translateX: randomX },
        { translateY: translateY + randomY },
        { scale },
      ],
    };
  });

  return (
    <Animated.Text style={[styles.particle, animatedStyle]}>
      {emoji}
    </Animated.Text>
  );
}

function SlideItem({ item, index, scrollX }) {
  const { fontSize, spacing } = useResponsiveDimensions();

  const animatedStyle = useAnimatedStyle(() => {
    const inputRange = [
      (index - 1) * width,
      index * width,
      (index + 1) * width,
    ];

    const opacity = interpolate(
      scrollX.value,
      inputRange,
      [0.3, 1, 0.3],
      Extrapolate.CLAMP
    );

    const scale = interpolate(
      scrollX.value,
      inputRange,
      [0.85, 1, 0.85],
      Extrapolate.CLAMP
    );

    const translateY = interpolate(
      scrollX.value,
      inputRange,
      [50, 0, -50],
      Extrapolate.CLAMP
    );

    return {
      opacity,
      transform: [
        { scale },
        { translateY },
      ],
    };
  });

  const iconAnimatedStyle = useAnimatedStyle(() => {
    const inputRange = [
      (index - 1) * width,
      index * width,
      (index + 1) * width,
    ];

    const rotateZ = interpolate(
      scrollX.value,
      inputRange,
      [-20, 0, 20],
      Extrapolate.CLAMP
    );

    const scale = interpolate(
      scrollX.value,
      inputRange,
      [0.7, 1, 0.7],
      Extrapolate.CLAMP
    );

    return {
      transform: [
        { scale },
        { rotateZ: `${rotateZ}deg` },
      ],
    };
  });

  return (
    <View style={styles.slide}>
      {item.particles.map((emoji, i) => (
        <Particle key={i} emoji={emoji} index={i} scrollX={scrollX} slideIndex={index} />
      ))}
      
      <Animated.View style={[styles.contentContainer, animatedStyle]}>
        <Animated.View style={iconAnimatedStyle}>
          <LinearGradient
            colors={item.gradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.iconGradientContainer}
          >
            <Ionicons name={item.icon} size={90} color={Colors.textLight} />
          </LinearGradient>
        </Animated.View>

        <View style={styles.textContainer}>
          <Text style={[styles.subtitle, { fontSize: fontSize.md }]}>{item.subtitle}</Text>
          <Text style={[styles.title, { fontSize: fontSize.huge }]}>{item.title}</Text>
          <View style={styles.divider} />
          <Text style={[styles.description, { fontSize: fontSize.lg }]}>{item.description}</Text>
        </View>
      </Animated.View>
    </View>
  );
}

export default function IntroScreen() {
  const router = useRouter();
  const flatListRef = useRef(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const scrollX = useSharedValue(0);
  const { spacing } = useResponsiveDimensions();

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollX.value = event.contentOffset.x;
    },
  });

  const backgroundAnimatedStyle = useAnimatedStyle(() => {
    const inputRange = slides.map((_, i) => i * width);
    const outputRange = slides.map(slide => slide.bgGradient[0]);
    
    const backgroundColor = interpolateColor(
      scrollX.value,
      inputRange,
      outputRange
    );

    return {
      backgroundColor,
    };
  });

  const handleGetStarted = () => {
    router.push('/(onboarding)/login');
  };

  const handleCreateAccount = () => {
    router.push('/(onboarding)/signup');
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <AnimatedBackground 
        gradientColors={slides[currentIndex]?.bgGradient || Colors.gradientTwilight}
        duration={10000}
      />

      <SafeAreaView style={styles.safeArea} edges={['top', 'bottom']}>
        <View style={styles.content}>
          <Animated.FlatList
            ref={flatListRef}
            data={slides}
            renderItem={({ item, index }) => (
              <SlideItem item={item} index={index} scrollX={scrollX} />
            )}
            keyExtractor={(item) => item.id}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onScroll={scrollHandler}
            scrollEventThrottle={16}
            onMomentumScrollEnd={(event) => {
              const index = Math.round(event.nativeEvent.contentOffset.x / width);
              setCurrentIndex(index);
            }}
          />

          <View style={styles.paginationContainer}>
            {slides.map((_, index) => {
              const dotAnimatedStyle = useAnimatedStyle(() => {
                const inputRange = [
                  (index - 1) * width,
                  index * width,
                  (index + 1) * width,
                ];

                const dotWidth = interpolate(
                  scrollX.value,
                  inputRange,
                  [8, 32, 8],
                  Extrapolate.CLAMP
                );

                const opacity = interpolate(
                  scrollX.value,
                  inputRange,
                  [0.4, 1, 0.4],
                  Extrapolate.CLAMP
                );

                return {
                  width: dotWidth,
                  opacity,
                };
              });

              return (
                <Animated.View
                  key={index}
                  style={[styles.dot, dotAnimatedStyle]}
                />
              );
            })}
          </View>
        </View>

        <View style={[styles.footer, { paddingHorizontal: spacing.xl }]}>
          <Button
            title="Começar Agora"
            onPress={handleGetStarted}
            variant="primary"
          />
          
          <Button
            title="Criar Conta Grátis"
            onPress={handleCreateAccount}
            variant="outline"
            style={{ marginTop: spacing.md }}
          />
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary,
  },
  safeArea: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  slide: {
    width,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing.xxl,
  },
  particle: {
    position: 'absolute',
    fontSize: 40,
    zIndex: 1,
  },
  contentContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing.xl,
  },
  iconGradientContainer: {
    width: 180,
    height: 180,
    borderRadius: BorderRadius.xxl * 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.xxxl,
  },
  textContainer: {
    alignItems: 'center',
    width: '100%',
  },
  subtitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textLight,
    textAlign: 'center',
    opacity: 0.9,
    textTransform: 'uppercase',
    letterSpacing: 2,
    marginBottom: Spacing.xs,
  },
  title: {
    fontSize: FontSizes.huge,
    fontWeight: FontWeights.extrabold,
    color: Colors.textLight,
    textAlign: 'center',
    marginBottom: Spacing.lg,
    letterSpacing: -0.5,
  },
  divider: {
    width: 60,
    height: 4,
    backgroundColor: Colors.textLight,
    borderRadius: BorderRadius.round,
    marginBottom: Spacing.lg,
    opacity: 0.8,
  },
  description: {
    fontSize: FontSizes.lg,
    color: Colors.textLight,
    textAlign: 'center',
    lineHeight: 28,
    opacity: 0.95,
    paddingHorizontal: Spacing.md,
  },
  paginationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.xxl,
    gap: Spacing.sm,
  },
  dot: {
    height: 8,
    borderRadius: BorderRadius.round,
    backgroundColor: Colors.textLight,
  },
  footer: {
    paddingBottom: Spacing.xl,
    gap: Spacing.md,
  },
});
