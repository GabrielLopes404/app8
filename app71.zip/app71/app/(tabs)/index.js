import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import Animated, {
  useAnimatedScrollHandler,
  useSharedValue,
} from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Colors, Spacing, FontSizes, FontWeights } from '../../constants/theme';
import GlassyHeader from '../../components/GlassyHeader';
import SearchCommandBar from '../../components/SearchCommandBar';
import PersonalizedHero from '../../components/PersonalizedHero';
import FloatingActionDock from '../../components/FloatingActionDock';
import SmartCarousel from '../../components/SmartCarousel';
import CategoryGridPremium from '../../components/CategoryGridPremium';
import StoreCardWorldClass from '../../components/StoreCardWorldClass';
import LiveTrackerWidget from '../../components/LiveTrackerWidget';
import LoyaltyCard from '../../components/LoyaltyCard';
import SectionHeader from '../../components/SectionHeader';
import SpecialOffersSection from '../../components/SpecialOffersSection';
import FeaturedProductsSection from '../../components/FeaturedProductsSection';
import PopularServicesSection from '../../components/PopularServicesSection';
import TestimonialsSection from '../../components/TestimonialsSection';
import StatisticsSection from '../../components/StatisticsSection';
import BenefitsSection from '../../components/BenefitsSection';
import HowItWorksSection from '../../components/HowItWorksSection';
import EmergencyVetSection from '../../components/EmergencyVetSection';
import { banners, categories, stores } from '../../constants/mockData';
import { useResponsiveLayout } from '../../hooks/useResponsiveLayout';

const AnimatedScrollView = Animated.createAnimatedComponent(ScrollView);

export default function HomeScreen() {
  const router = useRouter();
  const { spacing } = useResponsiveLayout();
  
  const [location, setLocation] = useState('Rua das Flores, 123');
  const [activeFilter, setActiveFilter] = useState('all');
  const scrollY = useSharedValue(0);

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollY.value = event.contentOffset.y;
    },
  });

  const featuredStores = stores.filter(s => s.isFeatured);
  const nearbyStores = stores.filter(s => !s.isFeatured);

  const carouselItems = banners.map(banner => ({
    ...banner,
    badge: banner.action === 'shop' ? '🛍️ Compre agora' : '📅 Agende',
  }));

  const handleLocationPress = () => {
    console.log('Location pressed');
  };

  const handleNotificationPress = () => {
    console.log('Notifications pressed');
  };

  const handleSearch = (query) => {
    console.log('Search:', query);
  };

  const handleFilterChange = (filter) => {
    setActiveFilter(filter);
    console.log('Filter changed:', filter);
  };

  const handleHeroCTA = () => {
    console.log('Hero CTA pressed');
  };

  const handleQuickAction = (action) => {
    console.log('Quick action:', action);
  };

  const handleCarouselItemPress = (item) => {
    console.log('Carousel item pressed:', item);
  };

  const handleCategoryPress = (category) => {
    console.log('Category pressed:', category);
  };

  const handleStorePress = (store) => {
    router.push(`/store/${store.id}`);
  };

  const handleTrackerPress = () => {
    console.log('Tracker pressed');
    router.push('/orders');
  };

  const handleLoyaltyPress = () => {
    console.log('Loyalty pressed');
  };

  const handleOfferPress = (offer) => {
    console.log('Offer pressed:', offer);
    router.push(`/product/${offer.id}`);
  };

  const handleProductPress = (product) => {
    console.log('Product pressed:', product);
    router.push(`/product/${product.id}`);
  };

  const handleAddToCart = (product) => {
    console.log('Add to cart:', product);
  };

  const handleServicePress = (service) => {
    console.log('Service pressed:', service);
    router.push('/booking');
  };

  const handleEmergencyCall = () => {
    console.log('Emergency call pressed');
  };

  const handleEmergencyChat = () => {
    console.log('Emergency chat pressed');
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <GlassyHeader
        location={location}
        onLocationPress={handleLocationPress}
        onNotificationPress={handleNotificationPress}
        scrollY={scrollY}
        hasNotification={true}
      />

      <AnimatedScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        onScroll={scrollHandler}
        scrollEventThrottle={16}
      >
        <SearchCommandBar
          onSearch={handleSearch}
          onFilterChange={handleFilterChange}
          placeholder="Buscar produtos, lojas, serviços..."
        />

        <PersonalizedHero
          userName="Pet Lover"
          title="Descubra o melhor para seu pet"
          subtitle="Produtos, serviços e cuidados especiais"
          ctaText="Explorar agora"
          onCTAPress={handleHeroCTA}
        />

        <FloatingActionDock
          onActionPress={handleQuickAction}
        />

        <LiveTrackerWidget
          onPress={handleTrackerPress}
        />

        <View style={styles.section}>
          <SpecialOffersSection
            onOfferPress={handleOfferPress}
          />
        </View>

        <View style={styles.section}>
          <SmartCarousel
            items={carouselItems}
            onItemPress={handleCarouselItemPress}
            autoPlay={true}
            autoPlayInterval={4000}
          />
        </View>

        <View style={styles.section}>
          <SectionHeader
            title="Categorias"
            subtitle="Explore nossos serviços"
            actionText=""
          />
          <CategoryGridPremium
            categories={categories}
            onCategoryPress={handleCategoryPress}
          />
        </View>

        <View style={styles.section}>
          <FeaturedProductsSection
            onProductPress={handleProductPress}
            onAddToCart={handleAddToCart}
          />
        </View>

        <View style={styles.section}>
          <LoyaltyCard
            points={450}
            maxPoints={500}
            level="Gold"
            nextReward="Banho grátis"
            onPress={handleLoyaltyPress}
          />
        </View>

        <View style={styles.section}>
          <SectionHeader
            title="Lojas em Destaque"
            subtitle="Selecionadas especialmente para você"
            actionText="Ver todas"
            onActionPress={() => console.log('See all featured')}
          />
          {featuredStores.map((store) => (
            <StoreCardWorldClass
              key={store.id}
              store={store}
              onPress={() => handleStorePress(store)}
              style={styles.storeCard}
            />
          ))}
        </View>

        <View style={styles.section}>
          <PopularServicesSection
            onServicePress={handleServicePress}
          />
        </View>

        <View style={styles.section}>
          <SectionHeader
            title="Perto de você"
            subtitle={`${nearbyStores.length} lojas disponíveis`}
            actionText="Ver mapa"
            onActionPress={() => console.log('View map')}
          />
          {nearbyStores.map((store) => (
            <StoreCardWorldClass
              key={store.id}
              store={store}
              onPress={() => handleStorePress(store)}
              style={styles.storeCard}
            />
          ))}
        </View>

        <View style={styles.bottomSpacing} />
      </AnimatedScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: Spacing.massive,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionHeaderContainer: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
  },
  storeCard: {
    marginBottom: Spacing.md,
  },
  bottomSpacing: {
    height: Spacing.xxxl,
  },
});
