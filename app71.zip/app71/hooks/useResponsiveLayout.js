import { useState, useEffect } from 'react';
import { Dimensions } from 'react-native';
import { Breakpoints, Spacing, FontSizes, FluidSpacing } from '../constants/theme';

export function useResponsiveLayout() {
  const [dimensions, setDimensions] = useState({
    window: Dimensions.get('window'),
    screen: Dimensions.get('screen'),
  });

  useEffect(() => {
    const subscription = Dimensions.addEventListener('change', ({ window, screen }) => {
      setDimensions({ window, screen });
    });

    return () => subscription?.remove();
  }, []);

  const { width: screenWidth, height: screenHeight } = dimensions.window;

  const getBreakpoint = () => {
    if (screenWidth >= Breakpoints.desktop) return 'xl';
    if (screenWidth >= Breakpoints.tablet) return 'lg';
    if (screenWidth >= Breakpoints.large) return 'md';
    if (screenWidth >= Breakpoints.medium) return 'sm';
    return 'xs';
  };

  const breakpoint = getBreakpoint();

  const fluidSpacing = FluidSpacing(screenWidth);

  const getGridColumns = (options = {}) => {
    const { xs = 2, sm = 2, md = 2, lg = 3, xl = 4 } = options;
    
    switch (breakpoint) {
      case 'xs': return xs;
      case 'sm': return sm;
      case 'md': return md;
      case 'lg': return lg;
      case 'xl': return xl;
      default: return 2;
    }
  };

  const getAdaptiveValue = (values) => {
    const { xs, sm, md, lg, xl } = values;
    
    switch (breakpoint) {
      case 'xs': return xs !== undefined ? xs : sm !== undefined ? sm : md;
      case 'sm': return sm !== undefined ? sm : md !== undefined ? md : lg;
      case 'md': return md !== undefined ? md : lg !== undefined ? lg : xl;
      case 'lg': return lg !== undefined ? lg : xl !== undefined ? xl : md;
      case 'xl': return xl !== undefined ? xl : lg !== undefined ? lg : md;
      default: return md;
    }
  };

  const scaleFont = (baseSize) => {
    const scaleFactor = screenWidth / 375;
    const minScale = 0.85;
    const maxScale = 1.15;
    const clampedScale = Math.max(minScale, Math.min(maxScale, scaleFactor));
    return Math.round(baseSize * clampedScale);
  };

  const getContainerWidth = () => {
    const padding = fluidSpacing.lg * 2;
    return screenWidth - padding;
  };

  const getContainerPadding = () => {
    return {
      paddingHorizontal: fluidSpacing.lg,
    };
  };

  const getCardWidth = (columns = 2, gap = Spacing.md) => {
    const containerWidth = getContainerWidth();
    const totalGap = gap * (columns - 1);
    return (containerWidth - totalGap) / columns;
  };

  const getResponsiveProp = (propName, baseValue) => {
    const scales = {
      xs: 0.85,
      sm: 0.92,
      md: 1,
      lg: 1.08,
      xl: 1.15,
    };
    
    const scale = scales[breakpoint] || 1;
    return baseValue * scale;
  };

  const isMobile = breakpoint === 'xs' || breakpoint === 'sm' || breakpoint === 'md';
  const isTablet = breakpoint === 'lg';
  const isDesktop = breakpoint === 'xl';

  const orientation = screenWidth > screenHeight ? 'landscape' : 'portrait';

  return {
    screenWidth,
    screenHeight,
    
    breakpoint,
    isXS: breakpoint === 'xs',
    isSM: breakpoint === 'sm',
    isMD: breakpoint === 'md',
    isLG: breakpoint === 'lg',
    isXL: breakpoint === 'xl',
    
    isMobile,
    isTablet,
    isDesktop,
    
    orientation,
    isPortrait: orientation === 'portrait',
    isLandscape: orientation === 'landscape',
    
    spacing: fluidSpacing,
    
    getGridColumns,
    getAdaptiveValue,
    scaleFont,
    getContainerWidth,
    getContainerPadding,
    getCardWidth,
    getResponsiveProp,
    
    containerStyle: {
      ...getContainerPadding(),
      maxWidth: isDesktop ? 1200 : isTablet ? 900 : '100%',
    },
    
    gridGap: fluidSpacing.md,
    
    cardSpacing: fluidSpacing.lg,
  };
}

export default useResponsiveLayout;
