import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows, Motion } from '../constants/theme';
import { useResponsiveLayout } from '../hooks/useResponsiveLayout';

const MOCK_ORDER = {
  id: '#1234',
  status: 'Em transporte',
  store: 'PetShop Premium',
  eta: '15 min',
  progress: 0.7,
};

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export default function LiveTrackerWidget({ order = MOCK_ORDER, onPress }) {
  const { spacing } = useResponsiveLayout();
  const pulse = useSharedValue(1);
  const progressWidth = useSharedValue(0);

  useEffect(() => {
    pulse.value = withRepeat(
      withSequence(
        withSpring(1.1, Motion.spring.gentle),
        withSpring(1, Motion.spring.gentle)
      ),
      -1,
      false
    );

    progressWidth.value = withTiming(order.progress, {
      duration: 1000,
    });
  }, [order.progress]);

  const pulseAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulse.value }],
  }));

  const progressAnimatedStyle = useAnimatedStyle(() => ({
    width: `${progressWidth.value * 100}%`,
  }));

  if (!order) return null;

  return (
    <AnimatedTouchable
      style={[styles.container, { marginHorizontal: spacing.lg }]}
      activeOpacity={0.9}
      onPress={onPress}
    >
      <LinearGradient
        colors={Colors.gradientPremiumViolet}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.gradient}
      >
        <View style={styles.content}>
          <View style={styles.header}>
            <Animated.View style={[styles.iconContainer, pulseAnimatedStyle]}>
              <View style={styles.iconInner}>
                <Ionicons name="bicycle" size={24} color={Colors.textLight} />
              </View>
            </Animated.View>

            <View style={styles.info}>
              <View style={styles.row}>
                <Text style={styles.orderId}>Pedido {order.id}</Text>
                <View style={styles.statusBadge}>
                  <Text style={styles.statusText}>{order.status}</Text>
                </View>
              </View>
              
              <Text style={styles.storeName} numberOfLines={1}>
                {order.store}
              </Text>
            </View>

            <View style={styles.etaContainer}>
              <Text style={styles.etaTime}>{order.eta}</Text>
              <Text style={styles.etaLabel}>restantes</Text>
            </View>
          </View>

          <View style={styles.progressContainer}>
            <View style={styles.progressBackground}>
              <Animated.View style={[styles.progressBar, progressAnimatedStyle]} />
            </View>
            
            <TouchableOpacity style={styles.trackButton} activeOpacity={0.8}>
              <Text style={styles.trackButtonText}>Acompanhar</Text>
              <Ionicons name="arrow-forward" size={14} color={Colors.textLight} />
            </TouchableOpacity>
          </View>
        </View>
      </LinearGradient>
    </AnimatedTouchable>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.lg,
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    ...Shadows.premiumMulti,
  },
  gradient: {
    padding: Spacing.lg,
  },
  content: {
    gap: Spacing.md,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  iconContainer: {
    width: 52,
    height: 52,
    borderRadius: BorderRadius.lg,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconInner: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  info: {
    flex: 1,
    gap: 4,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  orderId: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: 'rgba(255, 255, 255, 0.9)',
  },
  statusBadge: {
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: BorderRadius.xs,
  },
  statusText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  storeName: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  etaContainer: {
    alignItems: 'flex-end',
  },
  etaTime: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.extrabold,
    color: Colors.textLight,
    lineHeight: 28,
  },
  etaLabel: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.medium,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  progressBackground: {
    flex: 1,
    height: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: Colors.textLight,
    borderRadius: 3,
  },
  trackButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.md,
    gap: 4,
  },
  trackButtonText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textLight,
  },
});
